
#include <iostream>

int main() {
  int s = 0;
  int n;
  while (std::cin >> n) s += n;
  std::cout << "Somma = " << s << std::endl;
}
